package com.zahra.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.ai.edge.litertlm.Conversation
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var transcript: TextView
    private lateinit var prompt: EditText
    private lateinit var status: TextView
    private lateinit var sendButton: Button
    private var engine: Engine? = null
    private var conversation: Conversation? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val prefs by lazy { getSharedPreferences("zahra_memory", MODE_PRIVATE) }
    private val modelPickerCode = 4101
    private val audioPermissionCode = 4102
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
        transcript.text = prefs.getString("chat_log", "ZAHRA: Namaste! Main Zahra hoon. Model load karne ke baad main offline jawab de sakungi.\n") ?: ""
        val modelName = prefs.getString("model_name", null)
        status.text = if (modelName == null) "Offline brain: model select karna baaki hai" else "Saved model: $modelName"
        if (modelName != null) addLine("SYSTEM", "Model file saved hai. Offline brain load karne ke liye neeche Load Model dabao.")
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 30, 28, 20)
            setBackgroundColor(0xFF07111F.toInt())
        }
        val title = TextView(this).apply {
            text = "Z A H R A"
            textSize = 27f
            gravity = Gravity.CENTER
            setTextColor(0xFF8BD5FF.toInt())
        }
        val subtitle = TextView(this).apply {
            text = "PERSONAL AI  •  HYBRID EDITION"
            textSize = 11f
            gravity = Gravity.CENTER
            setTextColor(0xFF9DB4C9.toInt())
        }
        status = TextView(this).apply {
            text = "Starting..."
            textSize = 12f
            setTextColor(0xFFFFD27D.toInt())
            setPadding(4, 16, 4, 10)
        }
        transcript = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFE7F1FA.toInt())
            setPadding(14, 14, 14, 14)
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply {
            addView(transcript)
            setBackgroundColor(0xFF101F30.toInt())
        }
        val choose = Button(this).apply {
            text = "1. Select offline AI model (.litertlm)"
            setOnClickListener { chooseModel() }
        }
        val load = Button(this).apply {
            text = "2. Load offline brain"
            setOnClickListener { loadModel() }
        }
        val voice = Button(this).apply {
            text = "Speak to Zahra"
            setOnClickListener { startListening() }
        }
        prompt = EditText(this).apply {
            hint = "Yahan message likho..."
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9DB4C9.toInt())
            setSingleLine(false)
            minLines = 2
            setPadding(12, 8, 12, 8)
        }
        sendButton = Button(this).apply {
            text = "Send"
            setOnClickListener { sendMessage() }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(prompt, LinearLayout.LayoutParams(0, -2, 1f))
            addView(sendButton)
        }
        val online = TextView(this).apply {
            text = "ONLINE BRAIN: next stage mein provider/API connect hoga. Abhi koi paid API required nahi."
            textSize = 11f
            setTextColor(0xFF9DB4C9.toInt())
            setPadding(2, 8, 2, 2)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(choose)
        root.addView(load)
        root.addView(voice)
        root.addView(row)
        root.addView(online)
        setContentView(root)
    }

    private fun chooseModel() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, modelPickerCode)
    }

    @Deprecated("Using the document picker keeps this first build compatible with Android storage permissions.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == modelPickerCode && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            lifecycleScope.launch {
                try {
                    status.text = "Model file copy ho rahi hai..."
                    val file = withContext(Dispatchers.IO) {
                        val target = File(filesDir, "zahra-model.litertlm")
                        contentResolver.openInputStream(uri)?.use { input ->
                            target.outputStream().use { output -> input.copyTo(output) }
                        } ?: error("File read nahi ho payi")
                        target
                    }
                    prefs.edit().putString("model_name", file.name).apply()
                    status.text = "Model saved: ${file.name}. Ab Load offline brain dabao."
                    addLine("SYSTEM", "Model file app storage mein copy ho gayi.")
                } catch (e: Exception) {
                    status.text = "Model import failed"
                    toast("Model import error: ${e.message}")
                }
            }
        }
    }

    private fun loadModel() {
        val modelFile = File(filesDir, "zahra-model.litertlm")
        if (!modelFile.exists()) {
            toast("Pehle .litertlm model file select karo.")
            return
        }
        if (busy) return
        busy = true
        status.text = "Offline brain load ho raha hai. Pehli baar thoda waqt lag sakta hai..."
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    conversation?.close()
                    engine?.close()
                    val newEngine = Engine(EngineConfig(modelPath = modelFile.absolutePath))
                    newEngine.initialize()
                    engine = newEngine
                    conversation = newEngine.createConversation()
                }
                status.text = "Offline brain ready ✓"
                addLine("ZAHRA", "Main ready hoon. Ab internet ke bina bhi model se baat kar sakte ho.")
            } catch (e: Exception) {
                status.text = "Model load nahi hua"
                addLine("SYSTEM", "Model load error: ${e.message ?: "unknown error"}")
            } finally {
                busy = false
            }
        }
    }

    private fun sendMessage() {
        val text = prompt.text.toString().trim()
        if (text.isEmpty() || busy) return
        prompt.setText("")
        addLine("YOU", text)
        val activeConversation = conversation
        if (activeConversation == null) {
            addLine("ZAHRA", "Abhi offline model load nahi hua. Pehle model select karke Load offline brain dabao. Online brain agle stage mein connect hoga.")
            return
        }
        busy = true
        sendButton.isEnabled = false
        status.text = "ZAHRA soch rahi hai..."
        lifecycleScope.launch {
            try {
                val answer = withContext(Dispatchers.IO) {
                    val pieces = StringBuilder()
                    activeConversation.sendMessageAsync(text).collect { message ->
                        pieces.append(message.toString())
                    }
                    pieces.toString().ifBlank { "Model ne khaali response diya." }
                }
                addLine("ZAHRA", answer)
                tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "zahra_reply")
                status.text = "Offline brain ready ✓"
            } catch (e: Exception) {
                addLine("SYSTEM", "Response error: ${e.message ?: "unknown error"}")
                status.text = "Response mein error"
            } finally {
                busy = false
                sendButton.isEnabled = true
            }
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            toast("Is phone par speech recognition service available nahi hai.")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionCode)
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this).also { recognizer ->
            recognizer.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Sun rahi hoon..." }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "Aapki baat process ho rahi hai..." }
                override fun onError(error: Int) { status.text = "Voice input error: $error" }
                override fun onResults(results: Bundle?) {
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!spoken.isNullOrBlank()) {
                        prompt.setText(spoken)
                        sendMessage()
                    }
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            recognizer.startListening(intent)
        }
    }

    private fun addLine(who: String, text: String) {
        runOnUiThread {
            transcript.append("\n$who: $text\n")
            prefs.edit().putString("chat_log", transcript.text.toString()).apply()
        }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts?.language = Locale("hi", "IN")
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.shutdown()
        conversation?.close()
        engine?.close()
        super.onDestroy()
    }
}
