# ZAHRA AI Android - Starter v0.1.0

Ye pehla native Android starter project hai. Iska focus:
- Native Android app shell
- Chat transcript ka local save
- `.litertlm` model import using Android document picker
- Google AI Edge LiteRT-LM based on-device chat integration
- Android SpeechRecognizer input (Hindi preference)
- Android TextToSpeech reply

## Zaroori sach
- Is ZIP mein ready-made APK nahi hai.
- Offline chat tabhi chalegi jab compatible `.litertlm` model file import karoge.
- Is starter mein cloud/online AI provider abhi connected nahi hai. Hybrid online connector next development stage hai; bina API key/provider ke online AI nahi chalegi.
- Speech recognition service phone/Google speech services par depend kar sakti hai; har device par offline voice recognition guaranteed nahi.
- 1B class models bhi hundreds of MB se zyada ho sakte hain. 200-300 MB target ko quality/performance test ke bina promise nahi karte.
- LiteRT-LM model compatibility, memory use, and GPU backend must be tested on the actual OPPO device.

## Build karne ka sabse aasaan rasta
1. Is ZIP ko GitHub repository mein upload karo.
2. GitHub Actions tab kholo.
3. Workflow `Build ZAHRA Android APK` automatically run hoga after push.
4. Successful run ke Artifacts section se `ZAHRA-debug-apk` download karo.
5. APK phone par install karo. Unknown-app install permission Android settings se allow karni pad sakti hai.

## Model
Compatible `.litertlm` model Google AI Edge / LiteRT Community se choose karna hoga. Model ko APK ke andar bundle nahi kiya gaya; app ke andar file picker se import karna hai. Pehle small compatible model test karo. Model source and license ko install/use se pehle check karo.

## Development notes
- Package: `com.zahra.ai`
- Min SDK: 26
- Compile SDK: 36
- LiteRT-LM Android: 0.18.0
- Java/Kotlin target: 17

## Next stages
1. Verify and fix any compile/API issues against the selected LiteRT-LM model.
2. Add online AI settings with provider endpoint and user-supplied key, without hardcoding secrets.
3. Add persistent structured memory and search.
4. Add fully offline speech-to-text and voice selection.
5. Add safe Android actions with explicit user confirmation.
